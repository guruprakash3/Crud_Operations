package com.guru.model;

public class Books {

}
